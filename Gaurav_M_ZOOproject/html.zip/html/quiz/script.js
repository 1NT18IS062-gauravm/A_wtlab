const quizDB = [
  {
    question: "Q1: Which is the largest animal on the planet?",
    a: "Elephant",
    b: "Rat",
    c: "Giraffe",
    d: "Deer",
    ans: "ans1"
  },
  {
    question: "Q2: Which is the tallest animal on the planet?",
    a: "Elephant",
    b: "Rat",
    c: "Giraffe",
    d: "Rabbit",
    ans: "ans3"
  },
  {
    question: "Q3: Which animal using sound to navigate wher it is going?",
    a: "Tiger",
    b: "Lion",
    c: "Elephant",
    d: "Bat",
    ans: "ans4"
  },
  {
    question: "Q4: Which is the largest mammal in the world?",
    a: "Duck",
    b: "Human",
    c: "Shark",
    d: "Whale",
    ans: "ans4"
  },
  {
    question: "Q5: Which of these is not a mammal?",
    a: "Elephant",
    b: "Chicken",
    c: "Platypus",
    d: "Rat",
    ans: "ans2"
  },
  {
    question: "Q6: How many legs does a spider have?",
    a: "2",
    b: "8",
    c: "6",
    d: "4",
    ans: "ans2"
  }

];

const question = document.querySelector('.question');
const option1 = document.querySelector('#option1');
const option2 = document.querySelector('#option2');
const option3 = document.querySelector('#option3');
const option4 = document.querySelector('#option4');
const submit = document.querySelector('#submit');
const answers = document.querySelectorAll('.answer');

const showscore = document.querySelector('#showscore');
let questionCount = 0;
let score = 0;

const loadQuestion = () => {
  const questionList = quizDB[questionCount];
  question.innerText = questionList.question;

  option1.innerText = questionList.a;
  option2.innerText = questionList.b;
  option3.innerText = questionList.c;
  option4.innerText = questionList.d;
}
loadQuestion();

const getCheckAnswer = () => {
  let answer;

  answers.forEach((curAnsELem) => {
    if (curAnsELem.checked) {
      answer = curAnsELem.id;
    }
  });
  return answer;
};

const deselectAll = () => {
  answers.forEach((curAnsELem) => curAnsELem.checked = false);
}
submit.addEventListener('click', () => {
  const checkedAnswer = getCheckAnswer();
  console.log(checkedAnswer);

  if (checkedAnswer === quizDB[questionCount].ans) {
    score++;
  };

  questionCount++;
  deselectAll();

  if (questionCount < quizDB.length) {
    loadQuestion();
  } else {

    showscore.innerHTML = `
       <h2> You scored ${score}/${quizDB.length} !!</h2>
       <button class = "btn" onclick = "location.reload()">Play again</button>
       <button class= "btn" onclick ="location.href='../homepage/homepage.html'">Home</button>
       `;

    showscore.classList.remove('scorearea');

  }
});
