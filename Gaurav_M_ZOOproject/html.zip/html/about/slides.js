
var safIndex = 0;
function carSafari() {
  let i;
  let x = document.getElementsByClassName("mySlides1");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  safIndex++;
  if (safIndex > x.length) { safIndex = 1 }
  x[safIndex - 1].style.display = "block";
  setTimeout(carSafari, 2000); // Change image every 2 seconds
}

var aqIndex = 0;
function carAqua() {
  let i;
  let x = document.getElementsByClassName("mySlides2");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  aqIndex++;
  if (aqIndex > x.length) { aqIndex = 1 }
  x[aqIndex - 1].style.display = "block";
  setTimeout(carAqua, 2000); // Change image every 2 seconds
}

var petIndex = 0;
function carPet() {
  let i;
  let x = document.getElementsByClassName("mySlides3");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  petIndex++;
  if (petIndex > x.length) { petIndex = 1 }
  x[petIndex - 1].style.display = "block";
  setTimeout(carPet, 2000); // Change image every 2 seconds
}


var parkIndex = 0;
function carPark() {
  let i;
  let x = document.getElementsByClassName("mySlides4");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  parkIndex++;
  if (parkIndex > x.length) { parkIndex = 1 }
  x[parkIndex - 1].style.display = "block";
  setTimeout(carPark, 2000); // Change image every 2 seconds
}


carSafari();
carAqua();
carPet();
carPark();
