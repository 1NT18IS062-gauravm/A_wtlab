
function safari() {
  let safari = document.getElementById('safari');
  safari.style.visibility = "visible";
}
function aquarium() {
  let aquarium = document.getElementById('aquarium');
  aquarium.style.visibility = "visible";
}
function petZoo() {
  let petZoo = document.getElementById('petZoo');
  petZoo.style.visibility = "visible";
}
function themePark() {
  let themePark = document.getElementById('themePark');
  themePark.style.visibility = "visible";
}

